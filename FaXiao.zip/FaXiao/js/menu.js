/**
 * Created by Mr.Wang on 2016/12/10.
 */
$(function(){
    $(".btn").on("click",function(){
        $(".menu").css({display:"block"});
    })
})