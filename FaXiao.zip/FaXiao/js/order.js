/**
 * Created by Mr.Wang on 2016/12/13.
 */
$(function(){
    $("#address span").click(function(){
        $(".show").slideToggle(500);
    })
})