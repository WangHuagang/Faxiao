/**
 * Created by Mr.Wang on 2016/12/2.
 */
$(function(){
    $("#user").on("focus",function(){
       $("#show1").text("");
    })
    $("#user").on("blur",function(){
        $("#show1").text("�������˺�");
    })

})

